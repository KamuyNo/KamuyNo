"""Entradas Antecipadas - servidor em Python (WSGI, sem bibliotecas externas).

Rodar local:        SETUP_KEY="sua-chave" python app.py
Produção (gunicorn): gunicorn -w 1 --threads 4 app:application
PythonAnywhere:     veja o README.md (usa o objeto `application`)
"""
import os, json, hmac, hashlib, base64, secrets, time, re, threading

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("DATA_DIR") or os.path.join(BASE, "data")
DB_FILE = os.path.join(DATA_DIR, "db.json")
KEY_FILE = os.path.join(DATA_DIR, "secret.key")
SETUP_KEY = os.environ.get("SETUP_KEY", "")
os.makedirs(DATA_DIR, exist_ok=True)

LOCK = threading.RLock()
_db = {"funcionarios": {}, "lideres": {}, "entradas": {}}
_mtime = 0
TRIES = {}
ID_RE = re.compile(r"^[A-Za-z0-9_\-.~:@+]{1,100}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
TIME_RE = re.compile(r"^\d{2}:\d{2}$")
CARGOS = ("Supervisor", "Subgerente", "Gerente")

if not os.path.exists(KEY_FILE):
    with open(KEY_FILE, "w") as f:
        f.write(secrets.token_hex(32))
SECRET = open(KEY_FILE).read().strip().encode()


def load_db():
    """Recarrega o arquivo se ele mudou (seguro com mais de um processo)."""
    global _db, _mtime
    try:
        m = os.path.getmtime(DB_FILE)
    except OSError:
        return _db
    if m != _mtime:
        with open(DB_FILE, encoding="utf-8") as f:
            data = json.load(f)
        _db = {"funcionarios": {}, "lideres": {}, "entradas": {}, **data}
        _mtime = m
    return _db


def save_db():
    global _mtime
    tmp = DB_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(_db, f, ensure_ascii=False)
    os.replace(tmp, DB_FILE)
    _mtime = os.path.getmtime(DB_FILE)


def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return f"{salt}:{h}"


def check_pw(pw, stored):
    salt = stored.split(":")[0]
    return hmac.compare_digest(hash_pw(pw, salt), stored)


def make_token(mat):
    payload = base64.urlsafe_b64encode(json.dumps({"id": mat, "exp": time.time() + 12 * 3600}).encode()).decode()
    sig = hmac.new(SECRET, payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}"


def read_token(token):
    try:
        payload, sig = token.split(".")
        if not hmac.compare_digest(sig, hmac.new(SECRET, payload.encode(), hashlib.sha256).hexdigest()):
            return None
        d = json.loads(base64.urlsafe_b64decode(payload))
        return d["id"] if d["exp"] > time.time() else None
    except Exception:
        return None


def s(v, n=120):
    return str(v if v is not None else "").strip()[:n]


class Err(Exception):
    def __init__(self, code, msg):
        self.code, self.msg = code, msg


def public(rec):
    return {k: v for k, v in rec.items() if k != "senha"}


def handle(env):
    method, path = env["REQUEST_METHOD"], env.get("PATH_INFO", "/")
    qs = {k: v[0] for k, v in __import__("urllib.parse").parse.parse_qs(env.get("QUERY_STRING", "")).items()}
    body = {}
    if method in ("POST", "PUT"):
        n = int(env.get("CONTENT_LENGTH") or 0)
        if n > 100_000:
            raise Err(400, "Requisição grande demais")
        raw = env["wsgi.input"].read(n) if n else b""
        body = json.loads(raw) if raw else {}
        if not isinstance(body, dict):
            raise Err(400, "Requisição inválida")

    with LOCK:
        db = load_db()
        configured = any(l.get("cargo") == "Administrador" for l in db["lideres"].values())

        if path == "/api/status":
            return {"configured": configured}

        if path == "/api/setup" and method == "POST":
            if configured:
                raise Err(403, "O sistema já foi configurado.")
            if not SETUP_KEY:
                raise Err(403, "Defina a variável SETUP_KEY no servidor para liberar a configuração.")
            if not hmac.compare_digest(str(body.get("chave", "")), SETUP_KEY):
                raise Err(403, "Chave de configuração incorreta.")
            mat, nome, senha = s(body.get("matricula"), 100), s(body.get("nome")), str(body.get("senha") or "")
            if not ID_RE.match(mat) or not nome or len(senha) < 8:
                raise Err(400, "Informe matrícula, nome e senha (mínimo 8 caracteres).")
            db["lideres"][mat] = {"nome": nome, "cargo": "Administrador", "setor": "", "senha": hash_pw(senha)}
            save_db()
            return {"ok": 1}

        if path == "/api/login" and method == "POST":
            ip = env.get("HTTP_X_FORWARDED_FOR", env.get("REMOTE_ADDR", "")).split(",")[0].strip()
            t = TRIES.get(ip)
            if not t or time.time() > t[1]:
                t = [0, time.time() + 900]
            if t[0] >= 10:
                raise Err(429, "Muitas tentativas. Aguarde alguns minutos.")
            mat = s(body.get("matricula"), 100)
            l = db["lideres"].get(mat)
            ok = bool(l) and (l["cargo"] != "Administrador" or (l.get("senha") and check_pw(str(body.get("senha") or ""), l["senha"])))
            if not ok:
                t[0] += 1
                TRIES[ip] = t
                raise Err(401, "Senha incorreta." if l else "Matrícula não encontrada.")
            return {"token": make_token(mat), "me": {"id": mat, "nome": l["nome"], "cargo": l["cargo"], "setor": l.get("setor", "")}}

        # ---- rotas autenticadas
        tok = env.get("HTTP_AUTHORIZATION", "").replace("Bearer ", "")
        mat = read_token(tok)
        me = db["lideres"].get(mat) if mat else None
        if not me:
            raise Err(401, "Sessão inválida.")
        adm, sup = me["cargo"] == "Administrador", me["cargo"] == "Supervisor"

        m = re.match(r"^/api/c/(funcionarios|lideres|entradas)(?:/([^/]+))?$", path)
        if not m:
            raise Err(404, "Não encontrado")
        col, rid = m.group(1), m.group(2)
        if rid:
            from urllib.parse import unquote
            rid = unquote(rid)

        if method == "GET" and not rid:
            if col == "lideres" and not adm:
                raise Err(403, "Sem permissão")
            lst = [{"id": k, **public(v)} for k, v in db[col].items()]
            if col == "entradas":
                d, de, ate, st = qs.get("data"), qs.get("de"), qs.get("ate"), qs.get("setor")
                if sup:
                    lst = [e for e in lst if e["setor"] == me["setor"]]
                elif st:
                    lst = [e for e in lst if e["setor"] == st]
                if d: lst = [e for e in lst if e["data"] == d]
                if de: lst = [e for e in lst if e["data"] >= de]
                if ate: lst = [e for e in lst if e["data"] <= ate]
                lst.sort(key=lambda e: (e["nome"], e["setor"]))
                lst.sort(key=lambda e: e["data"], reverse=True)
                lst = lst[:5000]
            return lst

        if not rid or not ID_RE.match(rid):
            raise Err(400, "ID inválido")

        if method == "PUT":
            if col == "funcionarios":
                if not adm: raise Err(403, "Apenas o administrador.")
                nome, setor = s(body.get("nome")), s(body.get("setor"))
                if not nome or not setor: raise Err(400, "Dados inválidos")
                db["funcionarios"][rid] = {"nome": nome, "setor": setor}
            elif col == "lideres":
                if not adm: raise Err(403, "Apenas o administrador.")
                cargo, nome, setor = s(body.get("cargo")), s(body.get("nome")), s(body.get("setor"))
                if cargo not in CARGOS or not nome or (cargo == "Supervisor" and not setor):
                    raise Err(400, "Dados inválidos")
                if db["lideres"].get(rid, {}).get("cargo") == "Administrador":
                    raise Err(403, "Não é possível alterar o administrador.")
                db["lideres"][rid] = {"nome": nome, "cargo": cargo, "setor": setor if cargo == "Supervisor" else ""}
            else:
                f = db["funcionarios"].get(s(body.get("funcId"), 100))
                data, hor = str(body.get("data", "")), str(body.get("horario", ""))
                if not f or not DATE_RE.match(data) or not TIME_RE.match(hor):
                    raise Err(400, "Dados inválidos")
                if sup and f["setor"] != me["setor"]:
                    raise Err(403, "Setor não permitido.")
                db["entradas"][rid] = {"data": data, "funcId": body["funcId"], "nome": f["nome"], "setor": f["setor"],
                                       "horario": hor, "por": me["nome"], "porMat": mat, "ts": int(time.time() * 1000)}
            save_db()
            return {"ok": 1}

        if method == "DELETE":
            if col == "entradas":
                e = db["entradas"].get(rid)
                if e and sup and e["setor"] != me["setor"]:
                    raise Err(403, "Setor não permitido.")
            elif not adm:
                raise Err(403, "Apenas o administrador.")
            if col == "lideres" and db["lideres"].get(rid, {}).get("cargo") == "Administrador":
                raise Err(403, "Não é possível remover o administrador.")
            db[col].pop(rid, None)
            save_db()
            return {"ok": 1}

        raise Err(405, "Método inválido")


def application(env, start_response):
    path = env.get("PATH_INFO", "/")
    if not path.startswith("/api/"):
        if env["REQUEST_METHOD"] != "GET":
            start_response("405 Method Not Allowed", [])
            return [b""]
        with open(os.path.join(BASE, "public", "index.html"), "rb") as f:
            html = f.read()
        start_response("200 OK", [("Content-Type", "text/html; charset=utf-8"), ("X-Content-Type-Options", "nosniff")])
        return [html]
    try:
        code, out = 200, handle(env)
    except Err as e:
        code, out = e.code, {"erro": e.msg}
    except Exception:
        code, out = 400, {"erro": "Requisição inválida"}
    reasons = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 429: "Too Many Requests"}
    data = json.dumps(out, ensure_ascii=False).encode()
    start_response(f"{code} {reasons.get(code, 'Error')}", [("Content-Type", "application/json; charset=utf-8"),
                   ("Cache-Control", "no-store"), ("Content-Length", str(len(data)))])
    return [data]


if __name__ == "__main__":
    from wsgiref.simple_server import make_server
    port = int(os.environ.get("PORT", 3000))
    print(f"Rodando em http://localhost:{port}")
    make_server("0.0.0.0", port, application).serve_forever()
