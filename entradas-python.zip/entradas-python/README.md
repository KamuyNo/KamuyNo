# Entradas Antecipadas — versão Python

Sem bibliotecas obrigatórias (só a biblioteca padrão do Python 3.8+).
`gunicorn` é usado apenas em hospedagens que pedem um servidor de produção.

## Testar no seu computador
    SETUP_KEY="uma-chave-secreta" python app.py        # Linux/Mac
    set SETUP_KEY=uma-chave-secreta && python app.py   # Windows (cmd)
Abra http://localhost:3000 e faça a configuração inicial.

## Configuração inicial (nenhuma matrícula vem cadastrada)
Na primeira abertura, informe a SETUP_KEY, a matrícula, o nome e uma senha (mín. 8) do
administrador. Depois disso essa tela deixa de funcionar. Cadastre setores/funcionários e
só então os supervisores, subgerentes e gerentes.

## Variáveis de ambiente
- SETUP_KEY — chave para criar o administrador (obrigatória no primeiro acesso)
- DATA_DIR  — pasta onde ficam db.json e secret.key (precisa ser disco persistente)
- PORT      — porta no modo `python app.py` (padrão 3000)

## Opção 1 (mais fácil): PythonAnywhere
1. Crie uma conta em pythonanywhere.com.
2. Aba **Files** → envie o `.zip` e, no **Consoles → Bash**, rode: `unzip entradas-python.zip`
3. Aba **Web** → **Add a new web app** → **Manual configuration** → escolha Python 3.10 ou superior.
4. Na mesma aba, clique no link do **WSGI configuration file** e substitua TODO o conteúdo por:

       import os, sys
       path = '/home/SEU_USUARIO/entradas-python'
       if path not in sys.path:
           sys.path.insert(0, path)
       os.environ['SETUP_KEY'] = 'troque-por-uma-chave-secreta'
       os.environ['DATA_DIR'] = '/home/SEU_USUARIO/entradas-dados'
       from app import application

5. Crie a pasta de dados no Bash: `mkdir -p ~/entradas-dados`
6. Aba **Web** → **Reload**. O site fica em `https://SEU_USUARIO.pythonanywhere.com` (HTTPS já incluso).
7. Abra o site, conclua a configuração inicial e depois **apague** a linha da SETUP_KEY do arquivo WSGI.
Observação: no plano gratuito costuma ser preciso clicar periodicamente em um botão de
renovação na aba Web; confira as regras atuais do plano no site deles.

## Opção 2: Render (ou Railway/Fly)
1. Suba esta pasta para um repositório no GitHub.
2. No Render: **New → Web Service**, ligue ao repositório, Runtime **Python**.
3. Build: `pip install -r requirements.txt`   Start: `gunicorn -w 1 --threads 4 app:application`
4. Em **Environment**, defina SETUP_KEY e DATA_DIR=/var/data.
5. Anexe um **Disk** (plano pago) montado em /var/data. Sem disco persistente os dados se perdem a cada deploy.

## Opção 3: VPS próprio (Ubuntu)
    sudo apt install python3 python3-venv caddy
    cd /opt && unzip entradas-python.zip && cd entradas-python
    python3 -m venv venv && ./venv/bin/pip install -r requirements.txt
Crie `/etc/systemd/system/entradas.service`:

    [Unit]
    Description=Entradas Antecipadas
    After=network.target
    [Service]
    WorkingDirectory=/opt/entradas-python
    Environment=SETUP_KEY=troque-esta-chave
    Environment=DATA_DIR=/var/lib/entradas
    ExecStart=/opt/entradas-python/venv/bin/gunicorn -w 1 --threads 4 -b 127.0.0.1:8000 app:application
    Restart=always
    [Install]
    WantedBy=multi-user.target

    sudo mkdir -p /var/lib/entradas && sudo systemctl enable --now entradas
Para HTTPS automático, em `/etc/caddy/Caddyfile`:

    seudominio.com.br {
        reverse_proxy 127.0.0.1:8000
    }
    sudo systemctl reload caddy

## Importante
- Use **um** worker (`-w 1`); os dados ficam em arquivo.
- Faça backup periódico de `db.json` (e não apague `secret.key`, ou todos terão de logar de novo).
- Sempre use HTTPS.
